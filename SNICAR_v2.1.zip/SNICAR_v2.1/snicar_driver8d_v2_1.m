% Driver routine for SNICAR.  Also see commenting in snicar8d_v2.m
%
% Original version: written by Mark Flanner (flanner@umich.edu) Flanner et al. 2007 JGR
% Version 2: Updated by Cenlin He (cenlinhe@ucar.edu) He et al. 2018 ACP
% Original version assumes aerosol externally mixed with spherical snow grains 
% Current version includes nonspherical snow grain & BC-snow internal mixing 
% based on parameterizations from [He et al. 2017,J. Climate, doi:10.1175/JCLI-D-17-0300.1]
% Current version (2.1): Updated by Julian Gelman Constantin (juliangelman@cnea.gov.ar), Gelman Constantin et al. 2020, submited to The Cryosphere Discussions
% Original version includes only a simplified radiation scheme (Greenland Summit or midlatitude winter; clear sky or overcast).
% Current version accepts as input personalized clear sky direct and diffuse spectra and calculates spectra (and corrresponding albedo) 
% for clear sky, partly cloudy or overcast sky.
% As another improvement, we added the possibility of switching some of the key parameters in a range, output albedo results, and plot some of the results.
%
%
%%%%%%%%%%  Input parameters: %%%%%%%%%%%
% BND_TYP:      Spectral grid (=1 for 470 bands. This is the
%               only functional option in this distribution)
% DIRECT:       Direct or diffuse incident radiation (1=direct, 0=diffuse, 2=cloudy (must be used with spectra==3)
% APRX_TYP:     Two-Stream Approximation Type:
%                  1 = Eddington
%                  2 = Quadrature
%                  3 = Hemispheric Mean
%                  NOTE: Delta-Eddington Approximation is probably
%                  best for the visible spectrum, but can provide
%                  negative albedo in the near-IR under diffuse
%                  light conditions. Hence, the Hemispheric Mean
%                  approximation is recommended for general use.
% DELTA:        1=Use Delta approximation (Joseph, 1976), 0=don't use
% coszen:       cosine of solar zenith angle (only applies when DIRECT=1)
% R_sfc:        broadband albedo of underlying surface 
%                  (user can also define a spectrally-dependent albedo below)
% dz:           array of snow layer thicknesses [meters]. Top layer has index 1. 
%                  The length of this array defines number of snow layers
% rho_snw:      array of snow layer densities [kg m-3]. Must have same length as dz
% rds_snw:      array of snow layer effective grain radii [microns]. Must have same length as dz
% nbr_aer:      number of aerosol species in snowpack
% mss_cnc_sot1: mass mixing ratio of black carbon species 1 (uncoated BC)
%                 (units of parts per billion, ng g-1)
% mss_cnc_sot2: mass mixing ratio of black carbon species 2 (sulfate-coated BC)
%                 (units of parts per billion, ng g-1)
% mss_cnc_sot3: mass mixing ratio of black carbon species 3 (internally mixed with snow)
%                 (units of parts per billion, ng g-1) add by che
% mss_cnc_dst1: mass mixing ratio of dust species 1 (radii of 0.05-0.5um)
%                 (units of parts per billion, ng g-1)
% mss_cnc_dst2: mass mixing ratio of dust species 2 (radii of 0.5-1.25um)
%                 (units of parts per billion, ng g-1)
% mss_cnc_dst3: mass mixing ratio of dust species 3 (radii of 1.25-2.5um)
%                 (units of parts per billion, ng g-1)
% mss_cnc_dst4: mass mixing ratio of dust species 4 (radii of 2.5-5.0um)
%                 (units of parts per billion, ng g-1)
% mss_cnc_ash1: mass mixing ratio of volcanic ash species 1
%                 (units of parts per billion, ng g-1)
% fl_sot1:      name of file containing optical properties for BC species 1
% fl_sot2:      name of file containing optical properties for BC species 2
% fl_dst1:      name of file containing optical properties for dust species 1
% fl_dst2:      name of file containing optical properties for dust species 2
% fl_dst3:      name of file containing optical properties for dust species 3
% fl_dst4:      name of file containing optical properties for dust species 4
% fl_ash1:      name of file containing optical properties for ash species 1
%
%
%%%%% che %%%%%% Options added by Cenlin He, Apr. 2018
% SNO_SHP:      1=sphere (SNICAR default shape)
%               2=spheroid; 3=hexagonal plate; 4=koch snowflake;
% SNO_fs:       Shape factor: ratio of nonspherical grain effective radii to that of equal-volume sphere
%               0=use recommended default value (He et al. 2017 JC);
%               others(0<fs<1)= use user-specified value 
%               only activated when SNO_SHP > 1 (i.e. nonspherical)
% SNO_AR:       Aspect ratio: ratio of grain width to length
%               0=use recommended default value (He et al. 2017 JC);
%               others(0.1<fs<20)= use user-specified value
%               only activated when SNO_SHP > 1 (i.e. nonspherical)
% BC_SNO_MIX:   1= only BC-snow external mixing (SNICAR default)
%               2= BC-snow internal + external mixing
%%%%% che %%%%%%

%%%%% JGC %%%%%% Options added by Julian Gelman Constantin, Nov. 2019
% spectra:       1= mid-latitude winter, 2= Summit Greenland, 3= Personalized spectra (intended to be used with DIRECT==2, new option)
% diff_rat:      Value of diffuse to global ratio of incoming radiation, determined partly by cloudiness
% diff_ratS:     Value of diffuse to global ratio of incoming radiation for clear sky (as calculated by SMARTS, for instances)
% diff
% modify:        Select parameter to be switched in a range (1=rds_snw ; 2=rho_snw; 3=dz 4=slr_znt 5=diff_rat 6=mss_cnc_ash1)
% range:         Specifiy range of the chosen parameter
% 
% Files: diff_norm.txt, dir_norm.txt, diffuse and direct clear sky spectra, needed for DIRECT==2 and spectra==3.
%%%%% JGC %%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;

pkg load netcdf; % JGC. Optional: compatibility with Octave, in order to make "ncread" funtion work

% JGC. Select which parameter (besides concentration) will be modified
modify=4; %1=rds_snw ; 2=rho_snw; 3=dz 4=slr_znt 5=diff_rat 6=mss_cnc_ash1

% JGC. Example of input ranges for parameters
%range = 0:1000:100000 ; % mss_cnc_ash1 Ash concentration, surface layer (units: ng(species)/g(ice), or ppb) % site Acc5-2017
%range = 110:40:190 ; % rds_snw, surface layer  % site Acc5-2017
%range = 200:100:400 ; % rho_snw, surface layer % site Acc5-2017
%range = 0.08:0.01:0.10 ; % dz, surface layer % site Acc5-2017
%range = [84.44	81.95	79.39	76.81	74.28	71.79	69.36	67.00	64.73	62.55	60.47	58.52	56.70	55.02	53.51	52.16	51.02	50.08	49.36	48.87	48.61	48.60	48.83	49.28	49.98	50.89	52.00	53.31	54.81	56.46	58.27	60.21	62.28 64.44	66.71	69.06	71.49	73.98	76.52	79.12	81.75	84.42	87.11	89.80]; % slr_znt % Zenith range during April 5th, 2017, for the site
%range = [0.344 0.376 0.475] % diff_rat, for sky conditions of 25%, 33% and 50% cloudiness
% Currently, the script is prepared for an arbitrary range in the chosen parameter. Other parameters can be modified in a similar way with minors modifications in the code.

% RADIATIVE TRANSFER CONFIGURATION:
BND_TYP  = 1;        % 1= 470 spectral bands
DIRECT   = 2;        % 1= Direct-beam incident flux, 0= Diffuse incident flux, 2=Cloudy (additional input: spectra=3, diff_rat, diff_ratS, files diff_norm.txt and dir_norm.txt)
spectra   = 3;        % JGC. 1= mid-latitude winter, 2= Summit Greenland, 3= Personalized spectra (intended to be used with DIRECT==2)
diff_rat  = 0.376;      % JGC. Diffuse/Global ratio of incoming radiation. Only necessary if DIRECT == 2   % site Acc5-2017, 33% clouds
diff_ratS = 0.09912;      % JGC. SMARTS Clear-Sky Diffuse/Global ratio of incoming radiation. Only necessary if DIRECT == 2   % site Acc5-2017
Npt      = (diff_rat-diff_ratS)/(1-diff_ratS) % JGC. Cloud opacity factor, as calculated by Ernst et al 2016. Can be replaced by Gueymard approximation or other.
APRX_TYP = 3;        % 1= Eddington, 2= Quadrature, 3= Hemispheric Mean
DELTA    = 1;        % 1= Apply Delta approximation, 0= No delta

xx=0; % Loop counter, for output purposes
for parameter = range % Loop for parameter to be modified

if (modify==5)
  diff_rat=parameter;
  Npt      = (diff_rat-diff_ratS)/(1-diff_ratS); % JGC. Cloud opacity factor
end
 
% COSINE OF SOLAR ZENITH ANGLE FOR DIRECT-BEAM
if (modify==4)
  slr_znt=parameter;
else
  slr_znt = 50.85;         % Introduce zenith angle (in degrees), instead of cosine (Input if no range is used) 
endif
coszen=cos((slr_znt/360)*2*pi);
%coszen   = 1;

% REFLECTANCE OF SURFACE UNDERLYING SNOW:
%   Value is applied to all wavelengths.
%   User can also specify spectrally-dependent ground albedo
%   internally in snicar8d.m
R_sfc    = 0;

% SNOW LAYER THICKNESSES (array) (units: meters):
if (modify==3)
  dz1=parameter;
else
  dz1=0.09; % Acc5-2017 (Input if no range is used)
endif
dz       = [dz1, 0.01, 0.9];  % site Acc5-2017
 
nbr_lyr  = length(dz);  % number of snow layers

% SNOW DENSITY OF EACH LAYER (units: kg/m3)
if (modify==2)
  rho_snw1=parameter;
else
  rho_snw1=300; % site Acc5-2017 (Input if no range is used)
endif
rho_snw = [rho_snw1, 500, 500];  % site Acc5-2017
%rho_snw(1:nbr_lyr) = 300;

% SNOW EFFECTIVE GRAIN SIZE FOR EACH LAYER (units: microns):
if (modify==1)
  rds_snw1=parameter;
else
  rds_snw1=150; % site Acc5-2017 (Input if no range is used)
endif
rds_snw = [rds_snw1, 1000, 1000];  % site Acc5-2017

%%%% che %%%%%
% Options added by Cenlin He for nonspherical snow & BC-snow internal
% mixing based on He et al. (2017) parameterization 
% He et al. 2017: J. Climate, 30, doi:10.1175/JCLI-D-17-0300.1

SNO_SHP(1:nbr_lyr)  = 1;    % Snow grain shape option
                            % 1=sphere (SNICAR default shape)
                            % 2=spheroid; 3=hexagonal plate; 4=koch snowflake;
                            
SNO_fs(1:nbr_lyr)   = 0;    % Shape factor: ratio of nonspherical grain effective radii to that of sphere with the same volume.
                            % 0=use recommended default value (He et al. 2017 JC);
                            % others(0<fs<1)= use user-specified value
                            % only activated when SNO_SHP > 1 (i.e. nonspherical)
                            
SNO_AR(1:nbr_lyr)   = 0;    % Aspect ratio: ratio of grain width to length
                            % 0=use recommended default value (He et al. 2017 JC);
                            % others(0.1<fs<20)= use user-specified value
                            % only activated when SNO_SHP > 1 (i.e. nonspherical)
                            
BC_SNO_MIX(1:nbr_lyr) = 1;  % BC-snow mixing option
                            % 1= only BC-snow external mixing (SNICAR default)
                            % 2= BC-snow internal + external mixing
                            % Currently, can only deal with BC-snow internal
                            % mixing; internal mixing between snow and
                            % other aerosols will be added later
%%%% che %%%%%

  
% NUMBER OF AEROSOL SPECIES IN SNOW (ICE EXCLUDED)
%  Species numbers (used in snicar8d.m) are:
%    1: uncoated black carbon
%    2: coated black carbon
%    3: dust size 1
%    4: dust size 2
%    5: dust size 3
%    6: dust size 4
%    7: volcanic ash
nbr_aer = 7;

% PARTICLE MASS MIXING RATIOS (units: ng(species)/g(ice), or ppb)
if (modify==6)
  cnc_ash1=parameter;
else
  cnc_ash1=1280; % Acu01_2017 (Input if no range is used)
endif

mss_cnc_sot3(1:nbr_lyr)  = 0.0;    % che: black carbon internally mixed with snow
mss_cnc_sot1(1:nbr_lyr)  = 0.0;    % uncoated black carbon
mss_cnc_sot2(1:nbr_lyr)  = 0.0;    % coated black carbon
mss_cnc_dst1(1:nbr_lyr)  = 0.0;    % dust species 1
mss_cnc_dst2(1:nbr_lyr)  = 0.0;    % dust species 2
mss_cnc_dst3(1:nbr_lyr)  = 0.0;    % dust species 3
mss_cnc_dst4(1:nbr_lyr)  = 0.0;    % dust species 4
mss_cnc_ash1 = [cnc_ash1, 1379000, 25000]; % volcanic ash species 1 % site Acc5-2017
%mss_cnc_ash1(1:nbr_lyr)  = [22000, 1400000, 46600];    
% 1 ppm = 1000 ppb

 
% FILE NAMES CONTAINING MIE PARAMETERS FOR ALL AEROSOL SPECIES:
fl_sot1  = 'mie_sot_ChC90_dns_1317.nc';
fl_sot2  = 'miecot_slfsot_ChC90_dns_1317.nc';
fl_dst1  = 'aer_dst_bln_20060904_01.nc';
fl_dst2  = 'aer_dst_bln_20060904_02.nc';
fl_dst3  = 'aer_dst_bln_20060904_03.nc';
fl_dst4  = 'aer_dst_bln_20060904_04.nc';
fl_ash1  = 'volc_ash_mtsthelens_20081011.nc';


if (DIRECT<2)
% call SNICAR with these inputs:
% Original SNICAR by calling "snicar8d"
% che: Updated version by calling "snicar8d_v2"
% JGC: Updated version by calling "snicar8d_v2_1"
  data_in = snicar8d_v2_1(BND_TYP, DIRECT, APRX_TYP, DELTA, coszen, R_sfc, ...
                   dz, rho_snw, rds_snw, nbr_aer, mss_cnc_sot1, ...
                   mss_cnc_sot2, mss_cnc_dst1, mss_cnc_dst2, ...
                   mss_cnc_dst3, mss_cnc_dst4, mss_cnc_ash1, fl_sot1, ...
                   fl_sot2, fl_dst1, fl_dst2, fl_dst3, fl_dst4, fl_ash1, ...
                   SNO_SHP, BC_SNO_MIX, SNO_fs, SNO_AR, mss_cnc_sot3,...
                   spectra,diff_ratS,0);  % JGC. Force Npt=0 for direct < 2 
elseif (DIRECT==2)
   data_in = snicar8d_v2_1(BND_TYP, 0, APRX_TYP, DELTA, coszen, R_sfc, ...
                   dz, rho_snw, rds_snw, nbr_aer, mss_cnc_sot1, ...
                   mss_cnc_sot2, mss_cnc_dst1, mss_cnc_dst2, ...
                   mss_cnc_dst3, mss_cnc_dst4, mss_cnc_ash1, fl_sot1, ...
                   fl_sot2, fl_dst1, fl_dst2, fl_dst3, fl_dst4, fl_ash1, ...
                   SNO_SHP, BC_SNO_MIX, SNO_fs, SNO_AR, mss_cnc_sot3, ...
                   spectra,diff_ratS,Npt);  % JGC
    data_in2 = snicar8d_v2_1(BND_TYP, 1, APRX_TYP, DELTA, coszen, R_sfc, ...
                   dz, rho_snw, rds_snw, nbr_aer, mss_cnc_sot1, ...
                   mss_cnc_sot2, mss_cnc_dst1, mss_cnc_dst2, ...
                   mss_cnc_dst3, mss_cnc_dst4, mss_cnc_ash1, fl_sot1, ...
                   fl_sot2, fl_dst1, fl_dst2, fl_dst3, fl_dst4, fl_ash1, ...
                   SNO_SHP, BC_SNO_MIX, SNO_fs, SNO_AR, mss_cnc_sot3,...
                   spectra,diff_ratS,Npt);  % JGC                
endif
                   
% process input data:
% (see description of data_out at the end of snicar8d_v2.m for more info)
wvl         = data_in(:,1);   % wavelength grid
albedo      = data_in(:,2);   % spectral albedo
alb_slr     = data_in(1,3);   % broadband albedo (0.3-5.0um)
alb_vis     = data_in(2,3);   % visible albedo (0.3-0.7um)
alb_nir     = data_in(3,3);   % near-IR albedo (0.7-5.0um)
flx_abs_snw = data_in(4,3);   % total radiative absorption by all snow layers (not including underlying substrate)

flx_abs(1)     = data_in(6,4); % top layer solar absorption
flx_vis_abs(1) = data_in(7,4); % top layer VIS absorption
flx_nir_abs(1) = data_in(8,4); % top layer NIR absorption

if (DIRECT==2) %if (DIRECT ==2) data_in contains Diffuse radiation results and data_in2 Direct radiation results
  alb_slr_dir = data_in2(1,3);   % broadband albedo (0.3-5.0um)
  alb_vis_dir = data_in2(2,3);   % visible albedo (0.3-0.7um)
  alb_nir_dir = data_in2(3,3);   % near-IR albedo (0.7-5.0um)
endif

% when changing parameters in a range, keep data
xx=xx+1;
alb_plot(xx,1)=parameter;  % Value of the parameter modified during loop
alb_plot(xx,2)=alb_slr; % Direct albedo if DIRECT==1; Diffuse albedo if DIRECT==0 or DIRECT==2
alb_plot(xx,12)=alb_vis;
alb_plot(xx,22)=alb_nir;
if (DIRECT==2)
  alb_plot(xx,3)=alb_slr_dir; % Direct albedo 
  alb_plot(xx,13)=alb_vis_dir;
  alb_plot(xx,23)=alb_nir_dir;
  alb_plot(xx,4)=alb_slr_dir*(1-diff_rat)+alb_slr*diff_rat; % Net albedo (weighed average between direct and diffuse)
  alb_plot(xx,14)=alb_vis_dir*(1-diff_rat)+alb_vis*diff_rat;
  alb_plot(xx,24)=alb_nir_dir*(1-diff_rat)+alb_nir*diff_rat;
endif
end
if (DIRECT < 2)
  min_alb=min([min(alb_plot(:,2)) min(alb_plot(:,12)) min(alb_plot(:,22))]);
  max_alb=max([max(alb_plot(:,2)) max(alb_plot(:,12)) max(alb_plot(:,22))]);
elseif (DIRECT == 2)
  min_alb=min([min(alb_plot(:,4)) min(alb_plot(:,14)) min(alb_plot(:,24))]);
  max_alb=max([max(alb_plot(:,4)) max(alb_plot(:,14)) max(alb_plot(:,24))]);
endif
  ax1=subplot(3,1,1);
  if (DIRECT < 2)
    plot(ax1,alb_plot(:,1),alb_plot(:,2),'linewidth',3)
  elseif (DIRECT == 2)
    plot(ax1,alb_plot(:,1),alb_plot(:,4),'linewidth',3)
  endif
  set(gca,'ytick',0:0.05:1.0,'fontsize',16,'Ylim',[min_alb max_alb]);
  set(gca,'xtick',min(range):(max(range)-min(range))/10:max(range),'fontsize',16);
  ylabel('Albedo','fontsize',20);
  ax2=subplot(3,1,2);
  if (DIRECT < 2)
    plot(ax2,alb_plot(:,1),alb_plot(:,12),'linewidth',3)
  elseif (DIRECT == 2)
    plot(ax2,alb_plot(:,1),alb_plot(:,14),'linewidth',3)
  endif  
  set(gca,'ytick',0:0.05:1.0,'fontsize',16,'Ylim',[min_alb max_alb]);
  set(gca,'xtick',min(range):(max(range)-min(range))/10:max(range),'fontsize',16);
  ylabel('Albedo-Vis','fontsize',20);
  ax3=subplot(3,1,3);
  if (DIRECT < 2)
    plot(ax3,alb_plot(:,1),alb_plot(:,22),'linewidth',3)
  elseif (DIRECT == 2)
    plot(ax3,alb_plot(:,1),alb_plot(:,24),'linewidth',3)
  endif
  set(gca,'ytick',0:0.05:1.0,'fontsize',16,'Ylim',[min_alb max_alb]);
  set(gca,'xtick',min(range):(max(range)-min(range))/10:max(range),'fontsize',16);
  ylabel('Albedo-NIR','fontsize',20);
xlabel('Chosen parameter','fontsize',20);
grid on;

% Simple output example
csvwrite('albedo_curves.txt',alb_plot);